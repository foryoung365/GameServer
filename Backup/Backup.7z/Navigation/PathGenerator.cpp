////////////////////////////////////////////////////////////////////////
// Copyright(c) 1999-2015, All Rights Reserved
// Author:	FU YAN
// Created:	2015/05/11
// Describe:
////////////////////////////////////////////////////////////////////////
#include "PathGenerator.h"


CPathGenerator::CPathGenerator() : _polyLength(0), _type(PATHFIND_BLANK), _useStraightPath(false),
_forceDestination(false), _pointPathLimit(MAX_POINT_PATH_LENGTH), _straightLine(false),
_endPosition(G3D::Vec3f::zero()), _navMesh(NULL),
_navMeshQuery(NULL)
{
	memset(_pathPolyRefs, 0, sizeof(_pathPolyRefs));

	uint32 mapId = 0;

	
	_navMesh = NULL;
	_navMeshQuery = NULL;


	CreateFilter();
}
CPathGenerator::~CPathGenerator()
{

}

bool CPathGenerator::CalculatePath(float destX, float destY, float destZ, bool forceDest /*= false*/, bool straightLine /*= false*/)
{

}

void CPathGenerator::ReducePathLenghtByDist(float dist)
{

}

void CPathGenerator::NormalizePath()
{

}

bool CPathGenerator::InRange(G3D::Vec3f const& p1, G3D::Vec3f const& p2, float r, float h) const
{

}

float CPathGenerator::Dist3DSqr(G3D::Vec3f const& p1, G3D::Vec3f const& p2) const
{

}

bool CPathGenerator::InRangeYZX(float const* v1, float const* v2, float r, float h) const
{

}

dtPolyRef CPathGenerator::GetPathPolyByPosition(dtPolyRef const* polyPath, uint32 polyPathSize, float const* Point, float* Distance /*= NULL*/) const
{

}

dtPolyRef CPathGenerator::GetPolyByLocation(float const* Point, float* Distance) const
{

}

void CPathGenerator::BuildPolyPath(G3D::Vec3f const& startPos, G3D::Vec3f const& endPos)
{

}

void CPathGenerator::BuildPointPath(float const* startPoint, float const* endPoint)
{

}

void CPathGenerator::BuildShortcut()
{

}

void CPathGenerator::CreateFilter()
{

}

void CPathGenerator::UpdateFilter()
{

}

G3D::uint32 CPathGenerator::FixupCorridor(dtPolyRef* path, uint32 npath, uint32 maxPath, dtPolyRef const* visited, uint32 nvisited)
{

}

bool CPathGenerator::GetSteerTarget(float const* startPos, float const* endPos, float minTargetDist, dtPolyRef const* path, uint32 pathSize, float* steerPos, unsigned char& steerPosFlag, dtPolyRef& steerPosRef)
{

}

dtStatus CPathGenerator::FindSmoothPath(float const* startPos, float const* endPos, dtPolyRef const* polyPath, uint32 polyPathSize, float* smoothPath, int* smoothPathSize, uint32 smoothPathMaxSize)
{

}
