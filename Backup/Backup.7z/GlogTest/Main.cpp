////////////////////////////////////////////////////////////////////////
// Copyright(c) 1999-2015, All Rights Reserved
// Author:	FU YAN
// Created:	2015/05/05
// Describe:����
////////////////////////////////////////////////////////////////////////
#include "glog/logging.h"

using namespace google;

int main(void)
{
	InitGoogleLogging("");
	SetLogFilenameExtension(".log");
	SetLogDestination(GLOG_INFO, "GAMESERVER_INFO_");
	SetLogDestination(GLOG_WARNING, "GAMESERVER_WARNING_");
	SetLogDestination(GLOG_ERROR, "GAMESERVER_ERROR_");
	FLAGS_logbufsecs = 30;
	FLAGS_log_dir = "./";
	FLAGS_max_log_size = 10;
	FLAGS_logtostderr = false;
	LOG(INFO) << "This is Info log";
	LOG(WARNING) << "This is warnning log";
	LOG(ERROR) << "This is Error log";
	int a = 3;
	CHECK_INFO_RETURN(a == 2, a, 0);

	return 0;
}