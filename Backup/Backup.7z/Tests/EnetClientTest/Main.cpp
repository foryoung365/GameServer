////////////////////////////////////////////////////////////////////////
// Copyright(c) 1999-2015, All Rights Reserved
// Author:	FU YAN
// Created:	2015/05/05
// Describe:����
////////////////////////////////////////////////////////////////////////
#include "iostream"
#include "MyClientSocket.h"

using namespace std;
int main(void)
{
	IEnetSocket::InitEnetSocket();
	CMyClientSocket* pMyClientSocket = CMyClientSocket::CreateNew();
	EnetSocketInfo_t stInfo;
	memset(&stInfo, 0, sizeof(EnetSocketInfo_t));
	strcpy_s(stInfo.szIpAddr, "localhost");
	stInfo.u16Port = 5880;
	stInfo.u32MaxConn = 1;
	if (pMyClientSocket == NULL || !pMyClientSocket->Create(&stInfo))
	{
		if (pMyClientSocket)
		{
			pMyClientSocket->Release();
		}
		pMyClientSocket = NULL;
		return -1;
	}

	pMyClientSocket->Open();

	while (!pMyClientSocket->IsOpen())
	{
		pMyClientSocket->ProcessSocketEvent(0);
	}

	char szMsg[1024];

	while (1)
	{
		cin >> szMsg;
		pMyClientSocket->SendPacket(szMsg, strlen(szMsg));
		pMyClientSocket->ProcessSocketEvent(0);
	}

	if (pMyClientSocket)
	{
		pMyClientSocket->Release();
	}
	pMyClientSocket = NULL;

	IEnetSocket::DeinitEnetSocket();
	return 0;
}