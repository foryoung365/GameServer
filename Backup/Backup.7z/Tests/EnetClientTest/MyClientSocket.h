////////////////////////////////////////////////////////////////////////
// Copyright(c) 1999-2015, All Rights Reserved
// Author:	FU YAN
// Created:	2015/06/24
// Describe:
////////////////////////////////////////////////////////////////////////
#ifndef _MYSERVERSOCKET_H_
#define _MYSERVERSOCKET_H_

#include "EnetClientSocket.h"

class CMyClientSocket : public CEnetClientSocket
{
public:
	static CMyClientSocket* CreateNew() { return new CMyClientSocket; }
public:
	virtual void OnConnected(ENetPeer* pPeer);
	virtual void OnRecvPacket(ENetPeer* pPeer, ENetPacket* pPacket);
	virtual void OnDisconnected(ENetPeer* pPeer);
};

#endif	//end of define _MYSERVERSOCKET_H_