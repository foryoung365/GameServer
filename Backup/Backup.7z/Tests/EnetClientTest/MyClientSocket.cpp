////////////////////////////////////////////////////////////////////////
// Copyright(c) 1999-2015, All Rights Reserved
// Author:	FU YAN
// Created:	2015/06/24
// Describe:
////////////////////////////////////////////////////////////////////////
#include "MyClientSocket.h"
#include <iostream>

using namespace std;

void CMyClientSocket::OnConnected(ENetPeer* pPeer)
{
	printf("Peer[%p] Connected.\n", pPeer);
}

void CMyClientSocket::OnRecvPacket(ENetPeer* pPeer, ENetPacket* pPacket)
{
	printf("Received Packet[Size:%u] from Peer[%p]:%s\n", pPacket->dataLength, pPeer, pPacket->data);
}

void CMyClientSocket::OnDisconnected(ENetPeer* pPeer)
{
	printf("Peer[%p] Disconnected.\n", pPeer);
}
