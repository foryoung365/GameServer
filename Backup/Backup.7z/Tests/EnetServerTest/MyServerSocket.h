////////////////////////////////////////////////////////////////////////
// Copyright(c) 1999-2015, All Rights Reserved
// Author:	FU YAN
// Created:	2015/06/24
// Describe:
////////////////////////////////////////////////////////////////////////
#ifndef _MYSERVERSOCKET_H_
#define _MYSERVERSOCKET_H_

#include "EnetServerSocket.h"

class CMyServerSocket : public CEnetServerSocket
{
public:
	static CMyServerSocket* CreateNew() { return new CMyServerSocket; }
public:
	virtual void OnConnected(ENetPeer* pPeer);
	virtual void OnRecvPacket(ENetPeer* pPeer, ENetPacket* pPacket);
	virtual void OnDisconnected(ENetPeer* pPeer);
};

#endif	//end of define _MYSERVERSOCKET_H_