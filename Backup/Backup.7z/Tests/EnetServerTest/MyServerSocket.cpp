////////////////////////////////////////////////////////////////////////
// Copyright(c) 1999-2015, All Rights Reserved
// Author:	FU YAN
// Created:	2015/06/24
// Describe:
////////////////////////////////////////////////////////////////////////
#include "MyServerSocket.h"
#include <iostream>

using namespace std;

void CMyServerSocket::OnConnected(ENetPeer* pPeer)
{
	printf("Peer[%p] Connected.\n", pPeer);
}

void CMyServerSocket::OnRecvPacket(ENetPeer* pPeer, ENetPacket* pPacket)
{
	char szMsg[1024];
	memcpy(szMsg, pPacket->data, pPacket->dataLength);
	szMsg[pPacket->dataLength] = 0;
	printf("Received Packet[Size:%u] from Peer[%p]:%s\n", pPacket->dataLength, pPeer, szMsg);
	this->SendPacket(pPeer, "Packet Received!", strlen("Packet Received!"));
}

void CMyServerSocket::OnDisconnected(ENetPeer* pPeer)
{
	printf("Peer[%p] Disconnected.\n", pPeer);
}
