////////////////////////////////////////////////////////////////////////
// Copyright(c) 1999-2015, All Rights Reserved
// Author:	FU YAN
// Created:	2015/05/05
// Describe:����
////////////////////////////////////////////////////////////////////////
#include "iostream"
#include "MyServerSocket.h"

int main(void)
{
	IEnetSocket::InitEnetSocket();
	CMyServerSocket* pMyServerSocket = CMyServerSocket::CreateNew();
	EnetSocketInfo_t stInfo;
	memset(&stInfo, 0, sizeof(EnetSocketInfo_t));
	strcpy_s(stInfo.szIpAddr, "0.0.0.0");
	stInfo.u16Port = 5880;
	stInfo.u32MaxConn = 32;
	if (pMyServerSocket == NULL || !pMyServerSocket->Create(&stInfo))
	{
		if (pMyServerSocket)
		{
			pMyServerSocket->Release();
		}
		pMyServerSocket = NULL;

		return -1;
	}

	pMyServerSocket->Open();

	while (1)
	{
		pMyServerSocket->ProcessSocketEvent(0);
	}

	if (pMyServerSocket)
	{
		pMyServerSocket->Release();
	}
	pMyServerSocket = NULL;

	IEnetSocket::DeinitEnetSocket();

	return 0;
}