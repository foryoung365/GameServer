// ==================================================================
// Copyright 2014-2015 foryoung365@gmail.com, All rights Reserved. 
// Describe:ServerSocket use enet
// ==================================================================
#ifndef _SERVERSOCKET_H_
#define _SERVERSOCKET_H_

#include <map>
#include "IEnetSocket.h"

//��������socket��ʹ��Enet-UDP
class CEnetServerSocket : public IEnetSocket
{
protected:
	CEnetServerSocket();
	virtual ~CEnetServerSocket();

public:
	virtual void AddPeer(ENetPeer* pPeer);
	virtual void RemovePeer(ENetPeer* pPeer);
	virtual ENetPeer* QueryPeer(ENetPeer* pPeer);

public:
	virtual void BroadcastPacketToAll(void* pPacket, size_t nSize);
	virtual void BroadcastPacket(PEER_SET& setPeer, void* pPacket, size_t nSize);
	virtual void SendPacket(ENetPeer* pPeer, void* pPacket, size_t nSize);
	virtual void ProcessSocketEvent(uint32_t u32TimeoutMS = 0);
	virtual void DisconnectPeer(ENetPeer* pPeer);
public:
	virtual bool Create(EnetSocketInfo_t* pInfo);
	virtual bool Open(EnetSocketInfo_t* pInfo = NULL);
	virtual void Close();
	virtual bool IsOpen();
	//ʹ��ʱ�̳б��ಢʵ�����������ӿ�
public:
	virtual void OnConnected(ENetPeer* pPeer) = 0;
	virtual void OnRecvPacket(ENetPeer* pPeer, ENetPacket* pPacket) = 0;
	virtual void OnDisconnected(ENetPeer* pPeer) = 0;

protected:
	PEER_SET m_setPeers;
};

#endif //end of _SERVERSOCKET_H_