// ==================================================================
// Copyright 2014-2015 foryoung365@gmail.com, All rights Reserved. 
// Describe:
// ==================================================================
#ifndef _CLIENTSOCKET_H_
#define _CLIENTSOCKET_H_

#include "enet/enet.h"
#include "IEnetSocket.h"

//�ͻ���socket��ʹ��ENET-UDP
class CEnetClientSocket : public IEnetSocket
{
protected:
	CEnetClientSocket();
	virtual ~CEnetClientSocket();
public:
	virtual void ProcessSocketEvent(uint32_t u32TimeoutMS = 0);
	virtual void SendPacket(void* pPacket, size_t nSize);
public:
	virtual bool Create(EnetSocketInfo_t* pInfo);
	virtual bool Open(EnetSocketInfo_t* pInfo = NULL);
	virtual void Close();
	virtual bool IsOpen();
	//ʹ��ʱ�̳б��ಢʵ�����������ӿ�
public:
	virtual void OnConnected(ENetPeer* pPeer) = 0;
	virtual void OnRecvPacket(ENetPeer* pPeer, ENetPacket* pPacket) = 0;
	virtual void OnDisconnected(ENetPeer* pPeer) = 0;
protected:
	ENetPeer* m_pPeer;
};

#endif //end of _CLIENTSOCKET_H_