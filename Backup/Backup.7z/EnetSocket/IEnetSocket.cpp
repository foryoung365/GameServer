// ==================================================================
// Copyright 2014-2015 foryoung365@gmail.com, All rights Reserved. 
// Describe:
// ==================================================================
#include "IEnetSocket.h"

IEnetSocket::IEnetSocket()
{
	m_idSocket = SOCKET_NONE;
	m_eType = ENET_SOCKET_NONE;
	memset(&m_stSocketInfo, 0, sizeof(EnetSocketInfo_t));
	m_pSocket = NULL;
	memset(&m_stEvent, 0, sizeof(ENetEvent));
}

IEnetSocket::~IEnetSocket()
{
	enet_host_destroy(m_pSocket);
}

void IEnetSocket::InitEnetSocket()
{
	enet_initialize();
}

void IEnetSocket::DeinitEnetSocket()
{
	enet_deinitialize();
}

uint32_t IEnetSocket::IpAddrToUL(const char* szIpAddr)
{
	if (szIpAddr == NULL)
	{
		return 0;
	}

	uint32_t arUint[4];

	sscanf_s(szIpAddr, "%u.%u.%u.%u", &arUint[0], &arUint[1], &arUint[2], &arUint[3]);

	uint32_t ulIpAddr = arUint[0] << 24 | arUint[1] << 16 | arUint[2] << 8 | arUint[3];

	return ulIpAddr;
}

bool IEnetSocket::IpAddrToStr(uint32_t u32IpAddr, char* szIpAddr,int nSize)
{
	if (szIpAddr == NULL)
	{
		return false;
	}

	sprintf_s(szIpAddr, nSize, "%u.%u.%u.%u", u32IpAddr >> 24, (u32IpAddr << 8) >> 24, (u32IpAddr << 16) >> 24, (u32IpAddr << 24) >> 24);

	return true;
}

