// ==================================================================
// Copyright 2014-2015 foryoung365@gmail.com, All rights Reserved. 
// Describe:
// ==================================================================
#include "EnetServerSocket.h"

CEnetServerSocket::CEnetServerSocket()
{
	m_eType = ENET_SOCKET_SERVER;
}

CEnetServerSocket::~CEnetServerSocket()
{
}

bool CEnetServerSocket::Create(EnetSocketInfo_t* pInfo)
{
	if (pInfo == NULL)
	{
		return false;
	}

	memcpy(&m_stSocketInfo, pInfo, sizeof(EnetSocketInfo_t));

	m_idSocket = SOCKET_NONE;
	
	return true;
}


void CEnetServerSocket::ProcessSocketEvent(uint32_t u32TimeoutMS /*= 0*/)
{
	if (m_pSocket == NULL)
	{
		return;
	}

	if (enet_host_service(m_pSocket, &m_stEvent, u32TimeoutMS) <= 0)
	{
		return;
	}

	switch (m_stEvent.type)
	{
	case ENET_EVENT_TYPE_CONNECT:
	{
		this->AddPeer(m_stEvent.peer);
		this->OnConnected(m_stEvent.peer);
	}
	break;
	case ENET_EVENT_TYPE_DISCONNECT:
	{
		this->RemovePeer(m_stEvent.peer);
		this->OnDisconnected(m_stEvent.peer);
	}
	break;
	case ENET_EVENT_TYPE_RECEIVE:
	{
		this->OnRecvPacket(m_stEvent.peer, m_stEvent.packet);
		enet_packet_destroy(m_stEvent.packet);
	}
	break;
	default:
		break;
	}
}

void CEnetServerSocket::AddPeer(ENetPeer* pPeer)
{
	if (pPeer == NULL)
	{
		return;
	}

	m_setPeers.insert(pPeer);
}

void CEnetServerSocket::RemovePeer(ENetPeer* pPeer)
{
	if (pPeer == NULL)
	{
		return;
	}

	m_setPeers.erase(pPeer);	
}

ENetPeer* CEnetServerSocket::QueryPeer(ENetPeer* pPeer)
{
	if (pPeer == NULL)
	{
		return NULL;
	}

	PEER_SET::iterator it = m_setPeers.find(pPeer);
	if (it == m_setPeers.end())
	{
		return NULL;
	}

	return *it;
}

void CEnetServerSocket::BroadcastPacketToAll(void* pPacket, size_t nSize)
{
	if (m_pSocket == NULL)
	{
		return;
	}

	if (pPacket == NULL)
	{
		return;
	}

	ENetPacket* pSendPacket = enet_packet_create(pPacket, nSize, ENET_PACKET_FLAG_RELIABLE);
	if (pSendPacket == NULL)
	{
		return;
	}

	enet_host_broadcast(m_pSocket, SERVER_SOCKET_CHANNEL_SEND, pSendPacket);
}

void CEnetServerSocket::BroadcastPacket(PEER_SET& setPeer, void* pPacket, size_t nSize)
{
	if (m_pSocket == NULL)
	{
		return;
	}

	if (pPacket == NULL)
	{
		return;
	}

	ENetPacket* pSendPacket = enet_packet_create(pPacket, nSize, ENET_PACKET_FLAG_RELIABLE);
	if (pSendPacket == NULL)
	{
		return;
	}

	for (PEER_SET::iterator it = m_setPeers.begin(); it != m_setPeers.end(); ++it)
	{
		if (setPeer.find(*it) != setPeer.end())
		{
			enet_peer_send(*it, SERVER_SOCKET_CHANNEL_SEND, pSendPacket);
		}
	}
}

void CEnetServerSocket::SendPacket(ENetPeer* pPeer, void* pPacket, size_t nSize)
{
	if (m_pSocket == NULL)
	{
		return;
	}

	if (pPeer == NULL || pPacket == NULL || nSize <= 0)
	{
		return;
	}

	if (this->QueryPeer(pPeer) == NULL)
	{
		return;
	}

	ENetPacket* pSendPacket = enet_packet_create(pPacket, nSize, ENET_PACKET_FLAG_RELIABLE);
	if (pSendPacket == NULL)
	{
		return;
	}

	enet_peer_send(pPeer, SERVER_SOCKET_CHANNEL_SEND, pSendPacket);
}

bool CEnetServerSocket::Open(EnetSocketInfo_t* pInfo /*= NULL*/)
{
	if (this->IsOpen())
	{
		return true;
	}

	if (pInfo == NULL && m_stSocketInfo.u16Port == 0)
	{
		return false;
	}

	if (pInfo != NULL && !this->Create(pInfo))
	{
		return false;
	}

	ENetAddress stAddr;
	stAddr.host = htonl(IEnetSocket::IpAddrToUL(m_stSocketInfo.szIpAddr));
	stAddr.port = m_stSocketInfo.u16Port;

	m_pSocket = enet_host_create(&stAddr, m_stSocketInfo.u32MaxConn, SERVER_SOCKET_CHANNEL_MAX, m_stSocketInfo.u32MaxInBandWidth, m_stSocketInfo.u32MaxOutBandWidth);

	if (m_pSocket == NULL)
	{
		return false;
	}

	m_idSocket = m_pSocket->socket;

	return true;
}

void CEnetServerSocket::Close()
{
	if (!this->IsOpen())
	{
		return;
	}

	enet_host_destroy(m_pSocket);
	m_idSocket = SOCKET_NONE;
	m_pSocket = NULL;
}

bool CEnetServerSocket::IsOpen()
{
	return (m_idSocket != SOCKET_NONE);
}

void CEnetServerSocket::DisconnectPeer(ENetPeer* pPeer)
{
	if (pPeer == NULL)
	{
		return;
	}

	if (this->QueryPeer(pPeer) == NULL)
	{
		return;
	}

	enet_peer_disconnect(pPeer, 0);
}

