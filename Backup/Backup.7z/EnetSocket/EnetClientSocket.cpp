// ==================================================================
// Copyright 2014-2015 foryoung365@gmail.com, All rights Reserved. 
// Describe:
// ==================================================================
#include "EnetClientSocket.h"

CEnetClientSocket::CEnetClientSocket()
{
	m_eType = ENET_SOCKET_CLIENT;
	m_pPeer = NULL;
}

CEnetClientSocket::~CEnetClientSocket()
{

}

void CEnetClientSocket::SendPacket(void* pPacket, size_t nSize)
{
	if (m_pSocket == NULL)
	{
		return;
	}

	if (m_pPeer == NULL || pPacket == NULL || nSize <= 0)
	{
		return;
	}

	ENetPacket* pSendPacket = enet_packet_create(pPacket, nSize, ENET_PACKET_FLAG_RELIABLE);
	if (pSendPacket == NULL)
	{
		return;
	}

	enet_peer_send(m_pPeer, CLIENT_SOCKET_CHANNEL_SEND, pSendPacket);
}

void CEnetClientSocket::ProcessSocketEvent(uint32_t u32TimeoutMS /*= 0*/)
{
	if (m_pSocket == NULL)
	{
		return;
	}

	if (enet_host_service(m_pSocket, &m_stEvent, u32TimeoutMS) <= 0)
	{
		return;
	}

	switch (m_stEvent.type)
	{
	case ENET_EVENT_TYPE_CONNECT:
	{
		m_pPeer = m_stEvent.peer;
		this->OnConnected(m_stEvent.peer);
	}
	break;
	case ENET_EVENT_TYPE_DISCONNECT:
	{
		this->OnDisconnected(m_stEvent.peer);
		enet_peer_reset(m_pPeer);
		m_pPeer = NULL;
	}
	break;
	case ENET_EVENT_TYPE_RECEIVE:
	{
		this->OnRecvPacket(m_stEvent.peer, m_stEvent.packet);
		enet_packet_destroy(m_stEvent.packet);
	}
	break;
	default:
		break;
	}
}

bool CEnetClientSocket::Create(EnetSocketInfo_t* pInfo)
{
	if (pInfo == NULL)
	{
		return false;
	}

	memcpy(&m_stSocketInfo, pInfo, sizeof(EnetSocketInfo_t));

	m_pSocket = enet_host_create(NULL, 1, CLIENT_SOCKET_CHANNEL_MAX, pInfo->u32MaxInBandWidth, pInfo->u32MaxOutBandWidth);

	if (m_pSocket == NULL)
	{
		return false;
	}

	m_idSocket = m_pSocket->socket;

	return true;
}

bool CEnetClientSocket::Open(EnetSocketInfo_t* pInfo /*= NULL*/)
{
	if (this->IsOpen())
	{
		return true;
	}

	if (pInfo == NULL && m_pSocket == NULL)
	{
		return false;
	}

	if (pInfo != NULL && !this->Create(pInfo))
	{
		return false;
	}

	ENetAddress ObjAddr;
	enet_address_set_host(&ObjAddr, m_stSocketInfo.szIpAddr);
	ObjAddr.port = m_stSocketInfo.u16Port;

	enet_host_connect(m_pSocket, &ObjAddr, CLIENT_SOCKET_CHANNEL_MAX, 0);

	return true;
}

bool CEnetClientSocket::IsOpen()
{
	return (m_pPeer != NULL);
}

void CEnetClientSocket::Close()
{
	if (!this->IsOpen())
	{
		return;
	}

	enet_peer_disconnect(m_pPeer, 0);
	m_pPeer = NULL;
}

